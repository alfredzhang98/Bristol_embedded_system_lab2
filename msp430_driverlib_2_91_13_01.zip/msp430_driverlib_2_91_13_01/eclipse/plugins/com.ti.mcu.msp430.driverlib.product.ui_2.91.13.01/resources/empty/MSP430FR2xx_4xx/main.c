#include "driverlib.h"

int main(void) {

    WDT_A_hold(WDT_A_BASE);

    return (0);
}
