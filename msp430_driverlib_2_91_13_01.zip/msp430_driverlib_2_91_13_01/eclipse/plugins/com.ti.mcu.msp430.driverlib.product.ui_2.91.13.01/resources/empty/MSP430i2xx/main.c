#include "driverlib.h"

int main(void) {

    WDT_hold(WDT_BASE);

    return (0);
}
